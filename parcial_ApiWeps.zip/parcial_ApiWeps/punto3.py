import os
os.system("cls")

def analizar_texto(*args, **kwargs):
    
    # Si el usuario envía la opción contar_vocales se activa
    if kwargs.get("contar_vocales"):
        vocales = "aeiouAEIOU"  # lista de vocales
        total_vocales = 0       # contador de vocales

        # mira cada texto recibido en *args
        for texto in args:
            # mira cada letra del texto
            for letra in texto:
                # verificar si la letra es una vocal
                if letra in vocales:
                    total_vocales += 1

        print("Total de vocales:", total_vocales)

    # Si el usuario envía la opción contar_palabras se activa
    if kwargs.get("contar_palabras"):
        total_palabras = 0  # contador de palabras

        # recorrer cada texto recibido
        for texto in args:
            # split separa las palabras por espacios
            total_palabras += len(texto.split())

        print("Total de palabras:", total_palabras)


# un ejemplo
analizar_texto("Hola mundo", " no le se a Python", contar_vocales=True)