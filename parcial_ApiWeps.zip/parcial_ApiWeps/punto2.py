import os
os.system("cls")

#se calcula el descuento del 10%
def calcular_descuento(preco, descuento=10):
    return precio - (precio * descuento / 100)

total = 0
# pide al usuario que ingrese un precio para cada producto no imposta si es un decimal o un entero
for i in range(3):
    precio = float(input("Ingrese precio del producto: "))
    total += calcular_descuento(precio)
#muestra el total a pagar aplicando el descuento
print("Total a pagar:", total)