import os
os.system("cls")
# aqui donde se guardarán los estudiantes
estudiantes = []
# Ciclo para ingresar estudiantes hasta que el usuario escriba fin
while True:
    nombre = input("Ingrese nombre del estudiante (fin para terminar): ")
    # Si el usuario escribe fin se termina el ciclo
    if nombre == "fin":
        break
    # Se pide la nota del estudiante
    nota = float(input("Ingrese la nota: "))
    # Se guarda la información dentro de la lista
    estudiantes.append({"nombre": nombre, "nota": nota})
# se calcula el promedio de las notas
def promedio_notas(est):
    total = 0
    # Se suman todas las notas
    for e in est:
        total += e["nota"]
    # Se divide entre la cantidad de estudiantes
    return total / len(est)

# encuentra el estudiante con la nota más alta
def mejor_estudiante(est):
    mejor = est[0]  # se toma el primero como referencia
    for e in est:
        if e["nota"] > mejor["nota"]:
            mejor = e
    return mejor
# encuentra el estudiante con la nota más baja
def peor_estudiante(est):
    peor = est[0]  # se toma el primero como referencia
    for e in est:
        if e["nota"] < peor["nota"]:
            peor = e
    return peor
# Reporte final
print("Número de estudiantes:", len(estudiantes))
# Mostrar promedio
print("Promedio de notas:", promedio_notas(estudiantes))
# Mostrar mejor estudiante
mejor = mejor_estudiante(estudiantes)
print("Mejor estudiante:", mejor["nombre"], "-", mejor["nota"])
# Mostrar peor estudiante
peor = peor_estudiante(estudiantes)
print("Peor estudiante:", peor["nombre"], "-", peor["nota"])
#ordenar estudiantes de menor a mayor nota
ordenados = sorted(estudiantes, key=lambda x: x["nota"])
print("Estudiantes ordenados por nota:")
for e in ordenados:
    print(e["nombre"], "-", e["nota"])