import os
os.system("cls")

#pide al usuario que ingrese dos numeros por teclado
try:
    numero_a = int(input("Ingrese primer número: "))
    numero_b = int(input("Ingrese segundo número: "))
    
    print("Resultado:", numero_a/numero_b) # se dividen entre ellos mismos

# si el valor ingresado contiene alguna letra saltara un mensaje de error
except ValueError:
    print("Error : Debe ingresar números enteros")

# si el valor ingresado es 0 saltara un error
except ZeroDivisionError:
    print("Error : No se puede dividir entre cero")