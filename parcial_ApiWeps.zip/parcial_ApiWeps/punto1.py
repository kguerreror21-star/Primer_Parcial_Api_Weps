import os
os.system("cls")

#se pide al usuario un numero entero
n = int(input("Ingrese un número entero positivo: "))
primos = 0

#se hace un recorrido desde 2 hasta el numero ingresado
for num in range(2, n + 1):
    primo = True

#se verifica si el numero es divisible entre 2
    for i in range(2, num):
        if num % i == 0:
            primo = False
            break

    if primo:
        print(num)
        primos += 1
        
#se muestra la cantidad de numeros primos
print("Cantidad de primos:", primos)